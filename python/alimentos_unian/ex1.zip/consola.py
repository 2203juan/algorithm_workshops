#!/usr/bin/env python3
# -- coding: utf-8 --
"""
Created on Tue Feb 19 2:20:58 2021

@author: janeth_riveros
"""


import calculos as gatos

def main()->None:
    n_gatos = int(input("Ingrese la cantidad de gatos en el refugio: "))
    n_dias = int(input("Ingrese el número de días que los necesita alimentar: "))

    print(gatos.calcular_cantidad_comida(n_gatos, n_dias))

main()