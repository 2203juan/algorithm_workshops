
public class Node {
    public Node left;
    public Node right;
    public int data;
    
    public Node(){
        left = null;
        right = null;
        data = 0;
    }
    public Node(int d){
        left = null;
        right = null;
        data = d;
    }
}
